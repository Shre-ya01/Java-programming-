/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        String name;
        int age;
        int admn_no;
        int dob;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the name:");
        name= sc.nextLine();
        System.out.print("Enter the age:");
        age= sc.nextInt();
        System.out.print("Enter the admn_no:");
        admn_no= sc.nextInt();
        System.out.print("Enter the dob:");
        dob = sc.nextInt();
        System.out.print("Name:+name");
        System.out.print("age:+age");
        System.out.print("admn_no:+admn_no");
        System.out.print("dob:+dob");
    }
}
