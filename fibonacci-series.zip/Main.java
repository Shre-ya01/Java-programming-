/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
    public class Main
    {
        public static void main(String args[])
        {
            int num;
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter the number:");
            num = sc.nextInt();
            int prev=0;
            int next=1;
            for(int i = 0;i<=num;i++){
                int number = prev+next;
                System.out.print(" " +next);
                prev = next;
                next = number;
            }
        }
    }
